# Imposter Game - Setup Instructions

## Quick Setup (Copy these files manually)

You have the empty repo cloned at: C:\Users\parva\imposter-game

### Step 1: Create these files in your project folder

#### 1. package.json
```json
{
  "name": "imposter-game",
  "version": "1.0.0",
  "description": "AI-powered imposter game built with React",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.263.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.0.0",
    "vite": "^4.3.9",
    "tailwindcss": "^3.3.2",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.24"
  }
}
```

#### 2. index.html
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AI Imposter Game</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
```

#### 3. vite.config.js
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
})
```

#### 4. tailwind.config.js
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

#### 5. postcss.config.js
```javascript
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

#### 6. .gitignore
```
# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*

node_modules
dist
dist-ssr
*.local

# Editor directories and files
.vscode/*
!.vscode/extensions.json
.idea
.DS_Store
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?
```

#### 7. Create src folder and add files
- Create folder: src
- The App.jsx file is already in your Claude outputs folder
- Download src/main.jsx and src/index.css from outputs

### Step 2: Run these commands

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open browser to http://localhost:5173
```

### Step 3: Push to GitHub

```bash
git add .
git commit -m "Initial commit: AI Imposter Game with React"
git push -u origin main
```

### Step 4: Deploy to Vercel (Get Live Link)

1. Go to https://vercel.com
2. Sign in with GitHub
3. Click "New Project"
4. Select "imposter-game" repository
5. Click "Deploy"
6. Get your live URL!

## Need the actual files?

All project files are available in Claude's outputs folder. Download:
- src/App.jsx (main game component)
- src/main.jsx (React entry)
- src/index.css (Tailwind styles)
- All config files above

Then copy them to: C:\Users\parva\imposter-game
